import subprocess
import torch
from torch.utils.data import DataLoader
from torchvision.transforms import ToTensor, Resize  # Resize用于将图片改到对应尺寸
from inference_utils import VideoReader, VideoWriter
from PIL import Image
# import model
def api_invoking():
    

    # 设置要传递给 inference.py 的参数
    command = [
        'python', 'inference.py',
        '--variant', 'mobilenetv3',
        '--checkpoint', 'rvm_mobilenetv3.pth',
        '--device', 'cuda',
        '--input-source', 'input/processed/rgb_processed.mp4',
        '--output-type', 'video',
        '--output-composition', 'output/com/composition.mp4',
        '--output-alpha', 'output/alpha/alpha.mp4',
        '--output-foreground', 'output/for/foreground.mp4',
        '--output-video-mbps', '4',
        '--seq-chunk', '1'
    ]

    # 执行命令
    subprocess.run(command)

    
def full_commands():
    

    reader = VideoReader('input.mp4', transform=ToTensor())
    writer = VideoWriter('output.mp4', frame_rate=30)
    
    try:
        # 载入背景图片
        bgr_img = Image.open('/home/featurize/work/3DVision/background.jpg')
        # 调整背景图片大小，以匹配视频帧的大小
        # 假设输入视频帧的大小为（H, W），则应将背景图片调整到相同的大小
        H,W = 480,640
        resize_transform = Resize((H, W))  # 替换为实际视频帧的高度和宽度
        bgr_img_resized = resize_transform(bgr_img)

        # 将背景图片转换为Tensor
        bgr = ToTensor()(bgr_img_resized).cuda()
        print('background load success')
    except Exception as e:
        print (e)
        bgr = torch.tensor([.47, 1, .6]).view(3, 1, 1).cuda()  # 绿背景
        # return None
    
    rec = [None] * 4                                       # 初始记忆
    
    # 导入模型
    from model import MattingNetwork

    model = MattingNetwork(variant='mobilenetv3').eval().cuda() # 或 variant="resnet50"
    model.load_state_dict(torch.load('rvm_mobilenetv3.pth'))
    
    # 循环神经网络开始处理
    with torch.no_grad():
        for src in DataLoader(reader):
            fgr, pha, *rec = model(src.cuda(), *rec, downsample_ratio=0.25)  # 将上一帧的记忆给下一帧
            writer.write(fgr * pha + bgr * (1 - pha))


if __name__ == '__main__':
    full_commands()