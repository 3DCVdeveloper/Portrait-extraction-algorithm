# 把视频按照深度，把过深的或者0改为[0,0,0]

import numpy as np
import cv2

def main():

    # 视频文件路径
    rgb_video_path = 'input/RGB/rgb.mp4'
    depth_video_path = 'input/D/depth.mp4'

    # 打开视频文件
    rgb_cap = cv2.VideoCapture(rgb_video_path)
    depth_cap = cv2.VideoCapture(depth_video_path)

    # 检查视频是否成功打开
    if not rgb_cap.isOpened() or not depth_cap.isOpened():
        print("Error: Unable to open video files.")
        exit()
    
    # 获取视频信息
    fps = int(rgb_cap.get(cv2.CAP_PROP_FPS))
    width = int(rgb_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(rgb_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # 设置阈值
    depth_threshold = 100  # 深度阈值

    # 创建VideoWriter对象，用于保存处理后的视频
    output_video_path = 'input/processed/rgb_processed.mp4'
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    output_video = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

    while True:
        # 逐帧读取RGB和深度图像
        ret_rgb, frame_rgb = rgb_cap.read()
        ret_depth, frame_depth = depth_cap.read()

        if not ret_rgb or not ret_depth:
            break
        
        # 深度标量矩阵,只保留R通道
        scalar_depth = frame_depth[:,:,0]
        
        # 检查视频是否结束
        if not ret_rgb or not ret_depth:
            break

        # 处理深度图像
        depth_mask = (scalar_depth >= depth_threshold)
        frame_rgb[depth_mask] = [0, 0, 0]  # 将大于等于阈值的RGB像素替换为黑色

        # 写入处理后的帧到输出视频
        output_video.write(frame_rgb)

    # 释放资源
    rgb_cap.release()
    depth_cap.release()
    output_video.release()



if __name__ == '__main__':
    main()
            



    
